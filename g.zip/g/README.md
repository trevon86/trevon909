### VIAVIWEB Arbitrary File Upload vulnerability
mass upload viaviweb. <br>

## To Install & Execute
```
$ git clone https://github.com/Mantodkaz/viaviweb
$ cd viaviweb
$ python3 exploit.py
```
#### Note
This script is only for testing. so it is not equipped with threads or parallels.<br>therefore, if used for a large number of URLs it will take quite a long time.<br>but you can add it yourself to the code to overcome this.<br><br>
All your result vuln will saved in file result.txt



## Author
- MantodKaz

#### DISCAIMER !!
``I will not be held responsible for any direct or indirect damages caused by using this tool. use it only for educational purposes and you will not use it for any illegal activity.``

